package lab8_exercise_5;

import java.util.Scanner;

public class PosiviteOrNot {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
	
		for(int i=0;i<str.length();i++) {
			char[] charArray = str.toCharArray();
			
		}
	}
}
