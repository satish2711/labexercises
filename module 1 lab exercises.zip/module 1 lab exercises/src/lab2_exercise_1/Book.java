package lab2_exercise_1;

public class Book extends WrittenItem {

	public Book(int id_no, int no_of_copies, String title) {
		super(id_no, no_of_copies, title);
		// TODO Auto-generated constructor stub
	}

} 
