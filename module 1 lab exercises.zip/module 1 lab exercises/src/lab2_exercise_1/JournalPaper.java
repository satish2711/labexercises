package lab2_exercise_1;

public class JournalPaper extends WrittenItem{

	public JournalPaper(int id_no, int no_of_copies, String title) {
		super(id_no, no_of_copies, title);
		// TODO Auto-generated constructor stub
	}

}
