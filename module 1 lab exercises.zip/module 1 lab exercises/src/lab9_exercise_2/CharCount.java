package lab9_exercise_2;


import java.util.Map;

public class CharCount 
{
	public static void main(String[] args) 
	{
		
		int arr[]= {'a','r','a','t','b','a'};
		
	}
	
	public Map charCount( c[])
	{
		return mp;
		
	}
}