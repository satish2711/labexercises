package collectionexample;

public class TreeSetEx {
	public static void main(String[] args) {
		
		System.out.println("a".compareToIgnoreCase("B"));
		System.out.println("AF".compareToIgnoreCase("AB"));
		System.out.println("a".compareToIgnoreCase("C"));
		System.out.println("B".compareToIgnoreCase("B"));
		System.out.println("a".compareTo("qwertyuiop"));
	}
}
