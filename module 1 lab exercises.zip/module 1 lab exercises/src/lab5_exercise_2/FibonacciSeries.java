package lab5_exercise_2;

public class FibonacciSeries {
	
}
