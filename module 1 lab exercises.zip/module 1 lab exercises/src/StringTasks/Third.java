package StringTasks;

public class Third {
	public static void main(String[] args) {
		String s="Shubham";
		System.out.println(s.contains("abh"));
	}

}
