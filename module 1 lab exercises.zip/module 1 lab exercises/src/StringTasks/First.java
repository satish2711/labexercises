package StringTasks;

public class First {
	public static void main(String[] args) {
		String s="Shubham";
		System.out.println(s.charAt(3));
	}
}
